import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Contact Form
  app.post(api.contact.submit.path, async (req, res) => {
    try {
      const input = api.contact.submit.input.parse(req.body);
      await storage.createContactMessage(input);
      res.json({ success: true, message: "Message sent successfully" });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input" });
        return;
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Robots.txt
  app.get('/robots.txt', (req, res) => {
    const sitemapUrl = `https://${req.get('host')}/sitemap.xml`;
    res.type('text/plain');
    res.send(`User-agent: *\nAllow: /\nSitemap: ${sitemapUrl}`);
  });

  // Sitemap.xml
  app.get('/sitemap.xml', (req, res) => {
    const host = `https://${req.get('host')}`;
    const pages = [
      '', '/about', '/privacy', '/terms', '/contact', '/converter',
      // Currency Pairs
      '/usd-to-ngn', '/ngn-to-usd', '/eur-to-usd', '/usd-to-eur',
      '/gbp-to-usd', '/usd-to-gbp', '/usd-to-cad', '/usd-to-inr', '/usd-to-aed',
      // Calculators
      '/salary-to-hourly', '/vat-calculator', '/loan-interest-calculator',
      '/profit-margin-calculator', '/markup-calculator', '/inflation-calculator',
      // Guides
      '/guides/how-exchange-rates-work', '/guides/how-to-calculate-vat',
      '/guides/markup-vs-profit-margin', '/guides/how-loan-interest-is-calculated'
    ];

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${pages.map(path => `
  <url>
    <loc>${host}${path}</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>${path === '' || path === '/converter' ? 'daily' : 'weekly'}</changefreq>
    <priority>${path === '' ? '1.0' : path.startsWith('/guides') ? '0.8' : '0.9'}</priority>
  </url>`).join('')}
</urlset>`;

    res.type('application/xml');
    res.send(xml);
  });

  return httpServer;
}
