import { useState, useEffect } from 'react';

type Rates = Record<string, number>;

interface ExchangeRateData {
  base: string;
  date: string;
  rates: Rates;
}

interface UseExchangeRatesResult {
  rates: Rates | null;
  isLoading: boolean;
  error: string | null;
  lastUpdated: number | null;
  convert: (amount: number, from: string, to: string) => number;
}

const CACHE_KEY = 'exchange_rates_cache';
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes

export function useExchangeRates(baseCurrency: string = 'USD'): UseExchangeRatesResult {
  const [rates, setRates] = useState<Rates | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);

  useEffect(() => {
    const fetchRates = async () => {
      setIsLoading(true);
      setError(null);

      // Check Cache
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const { data, timestamp, base } = JSON.parse(cached);
        if (Date.now() - timestamp < CACHE_TTL && base === baseCurrency) {
          setRates(data.rates);
          setLastUpdated(timestamp);
          setIsLoading(false);
          return;
        }
      }

      try {
        // Primary API
        let response = await fetch(`https://api.exchangerate-api.com/v4/latest/${baseCurrency}`);
        
        if (!response.ok) {
          // Fallback API
          response = await fetch(`https://api.frankfurter.app/latest?from=${baseCurrency}`);
        }

        if (!response.ok) {
          throw new Error('Failed to fetch exchange rates');
        }

        const data: ExchangeRateData = await response.json();
        
        setRates(data.rates);
        setLastUpdated(Date.now());
        
        localStorage.setItem(CACHE_KEY, JSON.stringify({
          data,
          timestamp: Date.now(),
          base: baseCurrency
        }));
      } catch (err) {
        console.error('Exchange rate fetch error:', err);
        // Try to load stale cache if available
        if (cached) {
          const { data, timestamp } = JSON.parse(cached);
          setRates(data.rates);
          setLastUpdated(timestamp);
          setError('Using cached rates. Live updates unavailable.');
        } else {
          setError('Failed to load exchange rates. Please check your connection.');
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchRates();
  }, [baseCurrency]);

  const convert = (amount: number, from: string, to: string): number => {
    if (!rates) return 0;
    
    // If base matches 'from', direct conversion
    if (from === baseCurrency) {
      return amount * (rates[to] || 0);
    }
    
    // If we need to convert via base (e.g. EUR -> GBP when base is USD)
    // Formula: Amount / Rate(From) * Rate(To)
    const rateFrom = rates[from];
    const rateTo = rates[to];
    
    if (!rateFrom || !rateTo) return 0;
    
    return (amount / rateFrom) * rateTo;
  };

  return { rates, isLoading, error, lastUpdated, convert };
}
