import { useState } from "react";
import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useSubmitContact } from "@/hooks/use-contact";
import { Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactMessageSchema, type InsertContactMessage } from "@shared/schema";

export default function Contact() {
  const submitContact = useSubmitContact();
  
  const form = useForm<InsertContactMessage>({
    resolver: zodResolver(insertContactMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });

  const onSubmit = (data: InsertContactMessage) => {
    submitContact.mutate(data, {
      onSuccess: () => form.reset()
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>Contact Us - FinTools</title>
        <meta name="description" content="Get in touch with the FinTools team for support, feedback, or inquiries." />
      </Helmet>
      
      <Navbar />

      <main className="flex-grow py-16 md:py-24">
        <div className="container-width max-w-2xl">
          <div className="bg-white border border-border/50 rounded-2xl p-8 shadow-sm">
            <div className="text-center mb-10">
              <h1 className="text-3xl font-display font-bold text-slate-900 mb-4">Contact Us</h1>
              <p className="text-slate-600">
                Have questions or suggestions? We'd love to hear from you.
              </p>
            </div>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Full Name</label>
                <input
                  {...form.register("name")}
                  className={`input-field ${form.formState.errors.name ? 'border-red-500' : ''}`}
                  placeholder="John Doe"
                />
                {form.formState.errors.name && (
                  <p className="text-xs text-red-500">{form.formState.errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Email Address</label>
                <input
                  {...form.register("email")}
                  type="email"
                  className={`input-field ${form.formState.errors.email ? 'border-red-500' : ''}`}
                  placeholder="john@example.com"
                />
                {form.formState.errors.email && (
                  <p className="text-xs text-red-500">{form.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Message</label>
                <textarea
                  {...form.register("message")}
                  rows={5}
                  className={`input-field resize-none ${form.formState.errors.message ? 'border-red-500' : ''}`}
                  placeholder="How can we help you?"
                />
                {form.formState.errors.message && (
                  <p className="text-xs text-red-500">{form.formState.errors.message.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={submitContact.isPending}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                {submitContact.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                {submitContact.isPending ? "Sending..." : "Send Message"}
              </button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
