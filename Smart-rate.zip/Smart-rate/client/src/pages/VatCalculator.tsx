import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function VatCalculator() {
  const [amount, setAmount] = useState<string>("100");
  const [rate, setRate] = useState<string>("20");
  const [mode, setMode] = useState<"add" | "remove">("add");

  const calculate = () => {
    const a = parseFloat(amount) || 0;
    const r = parseFloat(rate) || 0;
    
    if (mode === "add") {
      const vat = a * (r / 100);
      return { net: a, vat, gross: a + vat };
    } else {
      const net = a / (1 + r / 100);
      const vat = a - net;
      return { net, vat, gross: a };
    }
  };

  const { net, vat, gross } = calculate();

  return (
    <CalculatorPage title="VAT Calculator" description="Calculate VAT amounts easily. add or remove VAT from gross/net amounts.">
      <div className="grid gap-6 max-w-md">
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Amount</label>
           <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">VAT Rate (%)</label>
           <input type="number" value={rate} onChange={e => setRate(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>
        <div className="flex gap-2">
            <button onClick={() => setMode("add")} className={`flex-1 px-4 py-2 rounded-md transition-colors ${mode === "add" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>Add VAT</button>
            <button onClick={() => setMode("remove")} className={`flex-1 px-4 py-2 rounded-md transition-colors ${mode === "remove" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>Remove VAT</button>
        </div>
        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
            <div className="flex justify-between items-center text-slate-600"><span>Net Amount</span><span className="font-mono text-lg">${net.toFixed(2)}</span></div>
            <div className="flex justify-between items-center text-slate-600"><span>VAT Amount</span><span className="font-mono text-lg">${vat.toFixed(2)}</span></div>
            <div className="h-px bg-slate-200 my-2"></div>
            <div className="flex justify-between items-center font-bold text-slate-900"><span>Gross Amount</span><span className="font-mono text-2xl">${gross.toFixed(2)}</span></div>
        </div>
      </div>
    </CalculatorPage>
  );
}
