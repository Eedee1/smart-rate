import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet><title>Privacy Policy - SmartRate Tools</title></Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>Privacy Policy</h1>
          <p>Last updated: February 12, 2026</p>
          <p>Your privacy is important to us. It is SmartRate Tools' policy to respect your privacy regarding any information we may collect from you across our website.</p>
          <h3>Information We Collect</h3>
          <p>We do not collect personal information unless you voluntarily provide it (e.g., via our contact form). We use local storage for preferences like cached exchange rates.</p>
          <h3>Cookies</h3>
          <p>We use cookies to improve your experience and to display personalized ads via Google AdSense.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
