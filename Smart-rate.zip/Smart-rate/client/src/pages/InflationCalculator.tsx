import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function InflationCalculator() {
  const [amount, setAmount] = useState<string>("1000");
  const [startYear, setStartYear] = useState<string>("2000");
  const [endYear, setEndYear] = useState<string>("2024");
  const [rate, setRate] = useState<string>("3.5"); // Simplified average rate

  const calculate = () => {
    const a = parseFloat(amount) || 0;
    const years = (parseInt(endYear) || 2024) - (parseInt(startYear) || 2000);
    const r = parseFloat(rate) || 3.5;
    
    if (years < 0) return { futureValue: a, change: 0 };

    const futureValue = a * Math.pow(1 + r / 100, years);
    const change = ((futureValue - a) / a) * 100;

    return { futureValue, change };
  };

  const { futureValue, change } = calculate();

  return (
    <CalculatorPage title="Inflation Calculator" description="Estimate the future value of money based on historical or expected inflation.">
      <div className="grid gap-6 max-w-md">
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Amount ($)</label>
           <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>
        <div className="grid grid-cols-2 gap-4">
            <div>
               <label className="block text-sm font-medium mb-1 text-slate-700">Start Year</label>
               <input type="number" value={startYear} onChange={e => setStartYear(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
            </div>
            <div>
               <label className="block text-sm font-medium mb-1 text-slate-700">End Year</label>
               <input type="number" value={endYear} onChange={e => setEndYear(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
            </div>
        </div>
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Avg Inflation Rate (%)</label>
           <input type="number" value={rate} onChange={e => setRate(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>

        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
            <div className="flex justify-between items-center text-slate-600"><span>Cumulative Change</span><span className="font-mono text-lg text-red-600">+{change.toFixed(1)}%</span></div>
            <div className="h-px bg-slate-200 my-2"></div>
            <div className="flex justify-between items-center font-bold text-slate-900"><span>Adjusted Value</span><span className="font-mono text-2xl">${futureValue.toFixed(2)}</span></div>
        </div>
      </div>
    </CalculatorPage>
  );
}
