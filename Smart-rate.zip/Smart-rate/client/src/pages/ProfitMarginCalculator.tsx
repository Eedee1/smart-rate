import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function ProfitMarginCalculator() {
  const [cost, setCost] = useState<string>("50");
  const [revenue, setRevenue] = useState<string>("100");

  const calculate = () => {
    const c = parseFloat(cost) || 0;
    const r = parseFloat(revenue) || 0;
    
    const profit = r - c;
    const margin = r > 0 ? (profit / r) * 100 : 0;
    const markup = c > 0 ? (profit / c) * 100 : 0;

    return { profit, margin, markup };
  };

  const { profit, margin, markup } = calculate();

  return (
    <CalculatorPage title="Profit Margin Calculator" description="Calculate profit margin, markup percentage, and total profit.">
      <div className="grid gap-6 max-w-md">
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Cost ($)</label>
           <input type="number" value={cost} onChange={e => setCost(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Revenue ($)</label>
           <input type="number" value={revenue} onChange={e => setRevenue(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>

        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
            <div className="flex justify-between items-center text-slate-600"><span>Profit</span><span className={`font-mono text-lg ${profit >= 0 ? "text-green-600" : "text-red-600"}`}>${profit.toFixed(2)}</span></div>
            <div className="flex justify-between items-center text-slate-600"><span>Markup</span><span className="font-mono text-lg">{markup.toFixed(2)}%</span></div>
            <div className="h-px bg-slate-200 my-2"></div>
            <div className="flex justify-between items-center font-bold text-slate-900"><span>Profit Margin</span><span className="font-mono text-2xl">{margin.toFixed(2)}%</span></div>
        </div>
      </div>
    </CalculatorPage>
  );
}
