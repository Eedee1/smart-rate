import { ReactNode } from "react";
import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { AdUnit } from "@/components/AdUnit";
import { Breadcrumb } from "@/components/Breadcrumb";

interface CalculatorPageProps {
  title: string;
  description: string;
  children: ReactNode;
}

export default function CalculatorPage({ title, description, children }: CalculatorPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>{title} - FinTools</title>
        <meta name="description" content={description} />
      </Helmet>
      
      <Navbar />

      <main className="flex-grow py-12">
        <div className="container-width">
          <div className="mb-8">
            <Breadcrumb items={[{ label: "Home", href: "/" }, { label: title }]} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8">
            <div className="space-y-8">
              <div className="bg-white border border-border/50 rounded-2xl p-6 md:p-8 shadow-sm">
                <h1 className="text-3xl font-display font-bold text-slate-900 mb-2">{title}</h1>
                <p className="text-slate-600 mb-8">{description}</p>
                
                {children}
              </div>

              <AdUnit slot="middle" />

              {/* SEO Content Area */}
              <article className="prose prose-slate max-w-none bg-white p-8 rounded-2xl border border-border/50">
                <h2>How to use this calculator</h2>
                <p>
                  This tool is designed to provide quick and accurate estimations based on standard financial formulas.
                  Simply input your values above and the result will update automatically.
                </p>
                <h3>Why is this important?</h3>
                <p>
                  Understanding these figures helps in making informed financial decisions, whether for personal budgeting
                  or business planning. Always consult with a financial advisor for professional advice.
                </p>
              </article>
            </div>

            {/* Sidebar */}
            <aside className="space-y-6">
              <div className="bg-white p-6 rounded-xl border border-border/50 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-4">Other Tools</h3>
                <nav className="space-y-2">
                  {[
                    { name: "Salary Calculator", href: "/salary-to-hourly" },
                    { name: "VAT Calculator", href: "/vat-calculator" },
                    { name: "Loan Interest", href: "/loan-interest" },
                    { name: "Profit Margin", href: "/profit-margin" },
                  ].map(link => (
                    <a key={link.href} href={link.href} className="block text-sm text-slate-600 hover:text-primary py-1">
                      {link.name}
                    </a>
                  ))}
                </nav>
              </div>
              
              <AdUnit slot="sidebar" />
            </aside>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
