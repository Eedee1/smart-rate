import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function SalaryCalculator() {
  const [salary, setSalary] = useState<string>("50000");
  const [period, setPeriod] = useState<"annual" | "monthly">("annual");
  const [hoursPerWeek, setHoursPerWeek] = useState<string>("40");

  const calculate = () => {
    const s = parseFloat(salary) || 0;
    const h = parseFloat(hoursPerWeek) || 40;
    
    let annual = period === "annual" ? s : s * 12;
    let monthly = annual / 12;
    let weekly = annual / 52;
    let daily = weekly / 5;
    let hourly = weekly / h;

    return { annual, monthly, weekly, daily, hourly };
  };

  const results = calculate();

  return (
    <CalculatorPage
      title="Salary to Hourly Calculator"
      description="Convert your annual or monthly salary into an hourly wage instantly."
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Salary Amount</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
              <input
                type="number"
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                className="input-field pl-8"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Pay Period</label>
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setPeriod("annual")}
                className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
                  period === "annual" ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-slate-700"
                }`}
              >
                Annual
              </button>
              <button
                onClick={() => setPeriod("monthly")}
                className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
                  period === "monthly" ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-slate-700"
                }`}
              >
                Monthly
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Hours per Week</label>
            <input
              type="number"
              value={hoursPerWeek}
              onChange={(e) => setHoursPerWeek(e.target.value)}
              className="input-field"
            />
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Your Earnings</h3>
          
          <div className="space-y-4">
            <ResultRow label="Hourly" value={results.hourly} highlight />
            <ResultRow label="Daily" value={results.daily} />
            <ResultRow label="Weekly" value={results.weekly} />
            <ResultRow label="Monthly" value={results.monthly} />
            <ResultRow label="Annual" value={results.annual} />
          </div>
        </div>
      </div>
    </CalculatorPage>
  );
}

function ResultRow({ label, value, highlight = false }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div className={`flex justify-between items-center p-3 rounded-lg ${highlight ? "bg-primary/5 border border-primary/10" : "border-b border-slate-200 last:border-0"}`}>
      <span className={`text-sm ${highlight ? "font-bold text-primary" : "text-slate-600"}`}>{label}</span>
      <span className={`font-mono ${highlight ? "text-xl font-bold text-primary" : "text-slate-900"}`}>
        ${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </span>
    </div>
  );
}
