import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function About() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet><title>About Us - SmartRate Tools</title></Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>About SmartRate Tools</h1>
          <p>SmartRate Tools is your trusted resource for financial calculations and currency conversion. Our mission is to provide accurate, fast, and easy-to-use tools for everyday financial decisions.</p>
          <h2>Our Mission</h2>
          <p>We believe financial clarity should be accessible to everyone. Whether you are a business owner calculating margins, a traveler converting currency, or planning a loan, we have the tools you need.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
