import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function HowLoanInterestIsCalculated() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>How Loan Interest is Calculated - SmartRate Tools</title>
      </Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <article className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>How Loan Interest is Calculated</h1>
          <p>Most loans use an amortization formula to determine equal monthly payments.</p>
          <h2>The Formula</h2>
          <pre>M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1 ]</pre>
          <ul>
            <li><strong>M:</strong> Total monthly payment</li>
            <li><strong>P:</strong> Principal loan amount</li>
            <li><strong>i:</strong> Monthly interest rate (Annual Rate / 12)</li>
            <li><strong>n:</strong> Number of payments (Years * 12)</li>
          </ul>
        </article>
      </main>
      <Footer />
    </div>
  );
}
