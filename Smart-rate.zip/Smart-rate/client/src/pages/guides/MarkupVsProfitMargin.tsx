import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function MarkupVsProfitMargin() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>Markup vs. Profit Margin - SmartRate Tools</title>
      </Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <article className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>Markup vs. Profit Margin</h1>
          <p>While both metrics measure profitability, they use different bases for calculation.</p>
          <h2>Markup</h2>
          <p>Markup is the percentage of profit relative to the <strong>Cost</strong>.</p>
          <pre>Markup % = (Profit / Cost) * 100</pre>
          <h2>Profit Margin</h2>
          <p>Profit Margin is the percentage of profit relative to the <strong>Revenue</strong> (Selling Price).</p>
          <pre>Margin % = (Profit / Revenue) * 100</pre>
        </article>
      </main>
      <Footer />
    </div>
  );
}
