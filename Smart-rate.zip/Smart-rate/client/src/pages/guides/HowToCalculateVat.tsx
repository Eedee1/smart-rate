import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function HowToCalculateVat() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>How to Calculate VAT - SmartRate Tools</title>
        <meta name="description" content="Learn the formulas for adding and removing VAT (Value Added Tax) from prices." />
      </Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <article className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>How to Calculate VAT</h1>
          <p>Value Added Tax (VAT) is a consumption tax placed on a product whenever value is added at each stage of the supply chain and at final sale.</p>
          
          <h2>Adding VAT to a Net Price</h2>
          <p>To calculate the Gross Price (Price including VAT):</p>
          <pre>Gross Price = Net Price * (1 + VAT Rate %)</pre>
          <p>Example (20% VAT): $100 * 1.20 = $120</p>

          <h2>Removing VAT from a Gross Price</h2>
          <p>To calculate the Net Price (Price excluding VAT):</p>
          <pre>Net Price = Gross Price / (1 + VAT Rate %)</pre>
          <p>Example (20% VAT): $120 / 1.20 = $100</p>

          <h2>Calculating the VAT Amount</h2>
          <p>If you have the Net Price: <code>VAT Amount = Net Price * VAT Rate</code></p>
          <p>If you have the Gross Price: <code>VAT Amount = Gross Price - (Gross Price / (1 + VAT Rate))</code></p>
        </article>
      </main>
      <Footer />
    </div>
  );
}
