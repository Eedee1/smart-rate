import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function HowExchangeRatesWork() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>How Exchange Rates Work - SmartRate Tools</title>
        <meta name="description" content="Understand the basics of currency exchange rates, how they are determined, and what factors influence them." />
      </Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <article className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>How Exchange Rates Work</h1>
          <p className="lead">Exchange rates determine the value of one currency relative to another. Understanding them is key to international travel, business, and investment.</p>
          
          <h2>What is an Exchange Rate?</h2>
          <p>An exchange rate is the price of one country's currency in terms of another currency. For example, if the USD/EUR rate is 0.92, it means 1 US Dollar is equal to 0.92 Euros.</p>
          
          <h2>Floating vs. Fixed Rates</h2>
          <p><strong>Floating Rates:</strong> Most major currencies (USD, EUR, GBP) have floating rates determined by supply and demand in the forex market. If demand for a currency rises, its value increases.</p>
          <p><strong>Fixed (Pegged) Rates:</strong> Some countries peg their currency to a major currency like the USD to maintain stability. The government buys or sells its own currency to keep the rate fixed.</p>

          <h2>Factors Influencing Rates</h2>
          <ul>
            <li><strong>Interest Rates:</strong> Higher interest rates offer lenders higher returns relative to other countries. Therefore, higher interest rates attract foreign capital and cause the exchange rate to rise.</li>
            <li><strong>Inflation:</strong> A country with consistently lower inflation exhibits a rising currency value, as its purchasing power increases relative to other currencies.</li>
            <li><strong>Political Stability:</strong> Investors prefer stable countries with strong economic performance. Turmoil can cause a loss of confidence and a drop in currency value.</li>
          </ul>

          <h2>The "Mid-Market" Rate</h2>
          <p>The rate you see on Google or news sites is the "mid-market" rate—the midpoint between the buy and sell prices of two currencies. Banks and exchange services typically add a "spread" or markup to this rate to make a profit.</p>
        </article>
      </main>
      <Footer />
    </div>
  );
}
