import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { CurrencyConverter } from "@/components/CurrencyConverter";
import { AdUnit } from "@/components/AdUnit";
import { Breadcrumb } from "@/components/Breadcrumb";

interface CurrencyPairPageProps {
  from: string;
  to: string;
}

export default function CurrencyPairPage({ from, to }: CurrencyPairPageProps) {
  const title = `Convert ${from} to ${to}`;
  const description = `Live ${from} to ${to} exchange rate converter. Calculate ${from} to ${to} with our free calculator.`;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>{title} - Live Exchange Rate</title>
        <meta name="description" content={description} />
      </Helmet>
      
      <Navbar />

      <main className="flex-grow py-12">
        <div className="container-width">
          <div className="mb-8">
            <Breadcrumb items={[{ label: "Home", href: "/" }, { label: title }]} />
          </div>

          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-center text-slate-900 mb-8">
              {from} to {to} Exchange Rate
            </h1>

            <div className="mb-12">
              <CurrencyConverter defaultFrom={from} defaultTo={to} />
            </div>

            <AdUnit slot="middle" />

            <article className="prose prose-slate max-w-none bg-white p-8 rounded-2xl border border-border/50 shadow-sm mt-8">
              <h2>Understanding the {from} to {to} Exchange Rate</h2>
              <p>
                The exchange rate between the <strong>{from}</strong> and <strong>{to}</strong> determines how much one unit of 
                currency is worth in the other currency. This rate fluctuates constantly due to global market conditions, 
                interest rates, and geopolitical events.
              </p>
              
              <h3>Factors Influencing {from}/{to} Rates</h3>
              <ul>
                <li><strong>Inflation Rates:</strong> Changes in market inflation cause currency exchange rates to change.</li>
                <li><strong>Interest Rates:</strong> Changes in interest rate affect currency value and dollar exchange rate.</li>
                <li><strong>Balance of Trade:</strong> A country's balance of trade (imports vs exports) impacts currency demand.</li>
                <li><strong>Government Debt:</strong> Public debt affects investor confidence and currency value.</li>
              </ul>

              <h3>Best Time to Convert {from} to {to}</h3>
              <p>
                Timing your currency exchange can save you money. Markets are most volatile during the overlap of 
                major trading sessions (London, New York, Tokyo). Monitoring trends over days or weeks can help 
                identify the optimal moment to trade.
              </p>
            </article>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
