import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { CurrencyConverter } from "@/components/CurrencyConverter";
import { Link } from "wouter";
import { ArrowRight, Calculator, TrendingUp, ShieldCheck } from "lucide-react";
import { AdUnit } from "@/components/AdUnit";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet>
        <title>FinTools - Free Currency Converter & Financial Calculators</title>
        <meta name="description" content="Professional financial tools including live currency converter, salary calculator, loan interest calculator, and more." />
      </Helmet>
      
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-white border-b border-border/50 py-16 md:py-24 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent opacity-50 pointer-events-none" />
          
          <div className="container-width relative z-10">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-xs font-bold tracking-wide uppercase mb-4">
                Trusted by 50,000+ Users
              </span>
              <h1 className="text-4xl md:text-6xl font-display font-bold text-slate-900 mb-6 leading-tight">
                Financial Calculations <br />
                <span className="text-primary">Made Simple</span>
              </h1>
              <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto">
                Accurate, real-time currency conversions and essential financial calculators for everyday use. No registration required.
              </p>
            </div>

            <div className="mb-16">
              <CurrencyConverter />
            </div>

            {/* Quick Links */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {[
                { label: "USD to NGN", href: "/usd-to-ngn" },
                { label: "EUR to USD", href: "/eur-to-usd" },
                { label: "GBP to USD", href: "/gbp-to-usd" },
                { label: "USD to CAD", href: "/usd-to-cad" },
              ].map(link => (
                <Link key={link.label} href={link.href} className="flex items-center justify-center p-3 bg-white border border-border rounded-lg text-sm font-medium text-slate-600 hover:text-primary hover:border-primary/30 hover:shadow-sm transition-all">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </section>

        <AdUnit slot="middle" className="container-width max-w-4xl mx-auto" />

        {/* Features Grid */}
        <section className="py-16 md:py-24 bg-slate-50">
          <div className="container-width">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-display font-bold text-slate-900 mb-4">Essential Tools</h2>
              <p className="text-slate-600">Everything you need to manage your finances better.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { 
                  icon: <Calculator className="w-6 h-6 text-primary" />,
                  title: "Salary Calculator",
                  desc: "Convert annual salary to hourly, monthly, or weekly rates.",
                  href: "/salary-to-hourly"
                },
                { 
                  icon: <TrendingUp className="w-6 h-6 text-primary" />,
                  title: "Profit Margin",
                  desc: "Calculate your gross and net profit margins instantly.",
                  href: "/profit-margin"
                },
                { 
                  icon: <ShieldCheck className="w-6 h-6 text-primary" />,
                  title: "Loan Calculator",
                  desc: "Understand your monthly payments and total interest.",
                  href: "/loan-interest"
                },
              ].map((feature, i) => (
                <Link key={i} href={feature.href} className="group interactive-card p-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                  <p className="text-slate-600 mb-6">{feature.desc}</p>
                  <div className="flex items-center text-primary font-semibold text-sm group-hover:gap-2 transition-all">
                    Use Tool <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
