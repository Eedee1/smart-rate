import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function LoanCalculator() {
  const [amount, setAmount] = useState<string>("10000");
  const [rate, setRate] = useState<string>("5.5");
  const [years, setYears] = useState<string>("5");

  const calculate = () => {
    const p = parseFloat(amount) || 0;
    const r = (parseFloat(rate) || 0) / 100 / 12;
    const n = (parseFloat(years) || 0) * 12;

    if (p <= 0 || r <= 0 || n <= 0) return { monthly: 0, total: 0, interest: 0 };

    const monthly = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const total = monthly * n;
    const interest = total - p;

    return { monthly, total, interest };
  };

  const results = calculate();

  return (
    <CalculatorPage
      title="Loan Interest Calculator"
      description="Calculate your monthly loan payments and total interest cost."
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Loan Amount</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="input-field pl-8"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Interest Rate (%)</label>
            <input
              type="number"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="input-field"
              step="0.1"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Loan Term (Years)</label>
            <input
              type="number"
              value={years}
              onChange={(e) => setYears(e.target.value)}
              className="input-field"
            />
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-6 border border-slate-100 flex flex-col justify-center">
          <div className="text-center mb-8">
            <div className="text-sm font-medium text-slate-500 mb-2">Monthly Payment</div>
            <div className="text-4xl font-display font-bold text-primary">
              ${results.monthly.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>

          <div className="space-y-4 pt-6 border-t border-slate-200">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-600">Total Interest</span>
              <span className="font-semibold text-red-500">
                ${results.interest.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-600">Total Payback</span>
              <span className="font-semibold text-slate-900">
                ${results.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </CalculatorPage>
  );
}
