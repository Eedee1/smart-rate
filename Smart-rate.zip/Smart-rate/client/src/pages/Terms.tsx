import { Helmet } from "react-helmet";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Terms() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Helmet><title>Terms of Service - SmartRate Tools</title></Helmet>
      <Navbar />
      <main className="flex-grow container-width py-12">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 max-w-3xl mx-auto prose prose-slate">
          <h1>Terms of Service</h1>
          <p>By accessing SmartRate Tools, you agree to these terms of service.</p>
          <h3>Disclaimer</h3>
          <p>The materials on SmartRate Tools are provided on an 'as is' basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability.</p>
          <h3>Financial Disclaimer</h3>
          <p>Content on this site is for informational purposes only and does not constitute financial advice.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
