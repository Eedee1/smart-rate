import { useState } from "react";
import CalculatorPage from "./CalculatorPage";

export default function MarkupCalculator() {
  const [cost, setCost] = useState<string>("50");
  const [markup, setMarkup] = useState<string>("20");

  const calculate = () => {
    const c = parseFloat(cost) || 0;
    const m = parseFloat(markup) || 0;
    
    const profit = c * (m / 100);
    const revenue = c + profit;
    const margin = revenue > 0 ? (profit / revenue) * 100 : 0;

    return { revenue, profit, margin };
  };

  const { revenue, profit, margin } = calculate();

  return (
    <CalculatorPage title="Markup Calculator" description="Determine selling price based on cost and desired markup percentage.">
      <div className="grid gap-6 max-w-md">
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Cost ($)</label>
           <input type="number" value={cost} onChange={e => setCost(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>
        <div>
           <label className="block text-sm font-medium mb-1 text-slate-700">Markup (%)</label>
           <input type="number" value={markup} onChange={e => setMarkup(e.target.value)} className="w-full p-2 border border-slate-300 rounded-md" />
        </div>

        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-3">
            <div className="flex justify-between items-center text-slate-600"><span>Profit</span><span className="font-mono text-lg text-green-600">${profit.toFixed(2)}</span></div>
            <div className="flex justify-between items-center text-slate-600"><span>Margin</span><span className="font-mono text-lg">{margin.toFixed(2)}%</span></div>
            <div className="h-px bg-slate-200 my-2"></div>
            <div className="flex justify-between items-center font-bold text-slate-900"><span>Selling Price</span><span className="font-mono text-2xl">${revenue.toFixed(2)}</span></div>
        </div>
      </div>
    </CalculatorPage>
  );
}
