import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Page Imports
import Home from "@/pages/Home";
import SalaryCalculator from "@/pages/SalaryCalculator";
import LoanCalculator from "@/pages/LoanCalculator";
import VatCalculator from "@/pages/VatCalculator";
import ProfitMarginCalculator from "@/pages/ProfitMarginCalculator";
import MarkupCalculator from "@/pages/MarkupCalculator";
import InflationCalculator from "@/pages/InflationCalculator";
import Contact from "@/pages/Contact";
import CurrencyPairPage from "@/pages/CurrencyPairPage";
import About from "@/pages/About";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";

// Guides
import HowExchangeRatesWork from "@/pages/guides/HowExchangeRatesWork";
import HowToCalculateVat from "@/pages/guides/HowToCalculateVat";
import MarkupVsProfitMargin from "@/pages/guides/MarkupVsProfitMargin";
import HowLoanInterestIsCalculated from "@/pages/guides/HowLoanInterestIsCalculated";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      
      {/* Calculators */}
      <Route path="/salary-to-hourly" component={SalaryCalculator} />
      <Route path="/loan-interest" component={LoanCalculator} />
      <Route path="/loan-interest-calculator" component={LoanCalculator} />
      <Route path="/vat-calculator" component={VatCalculator} />
      <Route path="/profit-margin" component={ProfitMarginCalculator} />
      <Route path="/profit-margin-calculator" component={ProfitMarginCalculator} />
      <Route path="/markup-calculator" component={MarkupCalculator} />
      <Route path="/inflation-calculator" component={InflationCalculator} />
      
      <Route path="/converter" component={Home} />

      {/* Pages */}
      <Route path="/contact" component={Contact} />
      <Route path="/about" component={About} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      
      {/* Guides */}
      <Route path="/guides/how-exchange-rates-work" component={HowExchangeRatesWork} />
      <Route path="/guides/how-to-calculate-vat" component={HowToCalculateVat} />
      <Route path="/guides/markup-vs-profit-margin" component={MarkupVsProfitMargin} />
      <Route path="/guides/how-loan-interest-is-calculated" component={HowLoanInterestIsCalculated} />

      {/* Currency Pairs */}
      <Route path="/usd-to-ngn"><CurrencyPairPage from="USD" to="NGN" /></Route>
      <Route path="/ngn-to-usd"><CurrencyPairPage from="NGN" to="USD" /></Route>
      <Route path="/eur-to-usd"><CurrencyPairPage from="EUR" to="USD" /></Route>
      <Route path="/usd-to-eur"><CurrencyPairPage from="USD" to="EUR" /></Route>
      <Route path="/gbp-to-usd"><CurrencyPairPage from="GBP" to="USD" /></Route>
      <Route path="/usd-to-gbp"><CurrencyPairPage from="USD" to="GBP" /></Route>
      <Route path="/usd-to-cad"><CurrencyPairPage from="USD" to="CAD" /></Route>
      <Route path="/usd-to-inr"><CurrencyPairPage from="USD" to="INR" /></Route>
      <Route path="/usd-to-aed"><CurrencyPairPage from="USD" to="AED" /></Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
