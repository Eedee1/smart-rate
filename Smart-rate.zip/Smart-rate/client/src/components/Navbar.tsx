import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Menu, X, ChevronDown, Calculator, Globe, BookOpen } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Converter", href: "/converter" },
  ];

  const tools = [
    { name: "Salary Calculator", href: "/salary-to-hourly" },
    { name: "VAT Calculator", href: "/vat-calculator" },
    { name: "Loan Interest", href: "/loan-interest" },
    { name: "Profit Margin", href: "/profit-margin" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border/50">
      <div className="container-width">
        <div className="flex justify-between h-20 items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/25 group-hover:scale-105 transition-transform duration-200">
              <Globe className="w-6 h-6" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-slate-900">
              FinTools<span className="text-primary">.</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href} 
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  location === link.href ? "text-primary font-semibold" : "text-slate-600"
                }`}
              >
                {link.name}
              </Link>
            ))}

            {/* Tools Dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-primary transition-colors py-2">
                Tools <ChevronDown className="w-4 h-4" />
              </button>
              <div className="absolute top-full left-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform translate-y-2 group-hover:translate-y-0">
                <div className="w-56 bg-white rounded-xl shadow-xl border border-border/50 p-2 flex flex-col gap-1">
                  {tools.map((tool) => (
                    <Link key={tool.name} href={tool.href} className="block px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 hover:text-primary rounded-lg transition-colors">
                      {tool.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            <Link href="/contact" className="btn-primary py-2 px-5 text-sm">
              Contact Us
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-b border-border/50 bg-white overflow-hidden"
          >
            <div className="container-width py-4 flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link 
                  key={link.name} 
                  href={link.href}
                  className="px-4 py-3 text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-primary rounded-lg"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <div className="px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">Calculators</div>
              {tools.map((tool) => (
                <Link 
                  key={tool.name} 
                  href={tool.href}
                  className="px-4 py-3 text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-primary rounded-lg pl-8"
                  onClick={() => setIsOpen(false)}
                >
                  {tool.name}
                </Link>
              ))}
              <div className="h-px bg-slate-100 my-2" />
              <Link 
                href="/contact"
                className="px-4 py-3 text-sm font-medium text-primary hover:bg-primary/5 rounded-lg"
                onClick={() => setIsOpen(false)}
              >
                Contact Support
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
