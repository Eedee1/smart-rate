import { Info } from "lucide-react";

interface AdUnitProps {
  slot: "top" | "middle" | "bottom" | "sidebar";
  className?: string;
}

export function AdUnit({ slot, className = "" }: AdUnitProps) {
  return (
    <div className={`my-8 bg-slate-50 border border-slate-200 rounded-xl overflow-hidden flex flex-col items-center justify-center relative ${className}`}>
      <div className="absolute top-2 right-2 text-[10px] text-slate-400 font-medium bg-slate-100 px-1.5 py-0.5 rounded uppercase tracking-wider flex items-center gap-1">
        Ad <Info className="w-3 h-3" />
      </div>
      
      <div className="p-8 text-center">
        <span className="text-slate-400 font-medium text-sm">Advertisement ({slot})</span>
        <div className="w-full h-full min-h-[100px] flex items-center justify-center">
          {/* AdSense Script placeholder */}
        </div>
      </div>
    </div>
  );
}
