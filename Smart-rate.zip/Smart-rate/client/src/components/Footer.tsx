import { Link } from "wouter";
import { Globe, Heart } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-50 border-t border-border/50 pt-16 pb-8">
      <div className="container-width">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white">
                <Globe className="w-5 h-5" />
              </div>
              <span className="font-display font-bold text-lg text-slate-900">FinTools.</span>
            </Link>
            <p className="text-slate-500 text-sm leading-relaxed">
              Professional financial tools and calculators for businesses and individuals. Accurate, fast, and free to use.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Calculators</h4>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><Link href="/converter" className="hover:text-primary transition-colors">Currency Converter</Link></li>
              <li><Link href="/salary-to-hourly" className="hover:text-primary transition-colors">Salary to Hourly</Link></li>
              <li><Link href="/vat-calculator" className="hover:text-primary transition-colors">VAT Calculator</Link></li>
              <li><Link href="/loan-interest" className="hover:text-primary transition-colors">Loan Interest</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Popular Pairs</h4>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><Link href="/usd-to-ngn" className="hover:text-primary transition-colors">USD to NGN</Link></li>
              <li><Link href="/eur-to-usd" className="hover:text-primary transition-colors">EUR to USD</Link></li>
              <li><Link href="/gbp-to-usd" className="hover:text-primary transition-colors">GBP to USD</Link></li>
              <li><Link href="/usd-to-cad" className="hover:text-primary transition-colors">USD to CAD</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><Link href="/about" className="hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-primary transition-colors">Contact</Link></li>
              <li><Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-sm">
            © {currentYear} FinTools Inc. All rights reserved.
          </p>
          <div className="flex items-center gap-1 text-slate-500 text-sm">
            Made with <Heart className="w-4 h-4 text-red-500 fill-current" /> for finance.
          </div>
        </div>
      </div>
    </footer>
  );
}
