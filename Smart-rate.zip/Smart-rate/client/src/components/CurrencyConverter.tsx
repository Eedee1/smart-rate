import { useState, useEffect } from "react";
import { useExchangeRates } from "@/hooks/use-exchange-rates";
import { ArrowRightLeft, RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

interface CurrencyConverterProps {
  defaultFrom?: string;
  defaultTo?: string;
}

const COMMON_CURRENCIES = [
  "USD", "EUR", "GBP", "NGN", "CAD", "AUD", "JPY", "CNY", "INR", "AED", "ZAR"
];

export function CurrencyConverter({ defaultFrom = "USD", defaultTo = "NGN" }: CurrencyConverterProps) {
  const [amount, setAmount] = useState<number>(1);
  const [from, setFrom] = useState(defaultFrom);
  const [to, setTo] = useState(defaultTo);
  
  const { rates, isLoading, error, lastUpdated, convert } = useExchangeRates("USD");
  
  const [result, setResult] = useState<number | null>(null);

  useEffect(() => {
    if (rates && amount > 0) {
      setResult(convert(amount, from, to));
    }
  }, [rates, amount, from, to]);

  const handleSwap = () => {
    setFrom(to);
    setTo(from);
  };

  const statusColor = error ? "text-red-500" : (lastUpdated && Date.now() - lastUpdated > 3600000) ? "text-amber-500" : "text-emerald-500";
  const statusIcon = error ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />;
  const statusText = error ? "Offline" : (lastUpdated && Date.now() - lastUpdated > 3600000) ? "Cached Rates" : "Live Rates";

  return (
    <div className="interactive-card p-6 md:p-8 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-display font-bold text-slate-900">Currency Converter</h2>
        <div className={`flex items-center gap-1.5 text-sm font-medium ${statusColor}`}>
          {statusIcon}
          {statusText}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-end">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Amount</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="input-field font-mono text-lg"
            min="0"
          />
        </div>

        <div className="flex justify-center pb-2">
          <button 
            onClick={handleSwap}
            className="p-3 rounded-full bg-slate-100 hover:bg-primary hover:text-white transition-all duration-200 active:scale-90"
          >
            <ArrowRightLeft className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">From</label>
          <select 
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="input-field font-semibold"
          >
            {COMMON_CURRENCIES.map(curr => (
              <option key={curr} value={curr}>{curr}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-4 mb-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">To</label>
          <select 
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="input-field font-semibold"
          >
            {COMMON_CURRENCIES.map(curr => (
              <option key={curr} value={curr}>{curr}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-slate-50 rounded-xl p-6 border border-slate-100 text-center">
        {isLoading ? (
          <div className="flex items-center justify-center gap-2 text-slate-500 py-2">
            <RefreshCw className="w-5 h-5 animate-spin" />
            <span>Updating rates...</span>
          </div>
        ) : (
          <motion.div
            key={`${amount}-${from}-${to}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="text-sm text-slate-500 mb-1">
              {amount} {from} =
            </div>
            <div className="text-4xl font-display font-bold text-slate-900 tracking-tight">
              {result?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {to}
            </div>
            <div className="text-xs text-slate-400 mt-2">
              1 {from} = {convert(1, from, to).toFixed(4)} {to}
            </div>
          </motion.div>
        )}
      </div>
      
      {lastUpdated && (
        <div className="mt-4 text-center text-xs text-slate-400">
          Last updated: {new Date(lastUpdated).toLocaleString()}
        </div>
      )}
    </div>
  );
}
