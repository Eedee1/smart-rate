## Packages
framer-motion | Page transitions and UI animations
recharts | Visualizing exchange rate trends (if historical data is added later) or loan amortization charts
lucide-react | Icons for UI elements (already in base, but listing for clarity)
date-fns | Date formatting for blog posts/guides

## Notes
API: https://api.exchangerate.host/latest (Primary), https://api.frankfurter.app/latest (Fallback)
Caching: Store exchange rates in localStorage with 10-minute TTL
SEO: Update document.title on route changes
Ad Units: Placeholders for AdSense
Theme: Professional Fintech Blue (#0052FF)
